PRFFECT trial run

#PREREQUISITES 

Please install the packages: "randomForest", "xtable", "caret", "prospectr", "signal", "rwt", "KernSmooth", "Peaks", "hyperSpec".

These should be installed using the dependencies = TRUE option, e.g. install.packages("randomForest", dependencies = TRUE)

#RUNNING THE TRIAL

STEP 1 - first the dataset must be split into training and test sets.  To do this, type: source("select_training_and_test_sets.r")
         
STEP 2 - Run the program by: source("PRFFECTv1.r")

Optionally, tr_prop in the set selection script can be changed.  Also, the pre-processing selection in user_defined_input.R can be changed.