PRFFECT trial run

#PREREQUISITES 

Please install the packages: "randomForest", "xtable", "caret", "prospectr", "signal", "rwt", "KernSmooth", "Peaks", "hyperSpec".

These should be installed using the dependencies = TRUE option, e.g. install.packages("randomForest", dependencies = TRUE)

#RUNNING THE TRIAL

STEP 1 - first the dataset must be split into training and test sets.  
To do this, type: source("select_training_and_test_sets.r")
Optionally, tr_prop in the set selection script can be changed.  

STEP 2 (optional) - The pre-processing selection in user_defined_input.R can be changed.

STEP 3 - Run the program by: source("PRFFECTv1.r")
The output can then be examined.  See contents of 'example_output.zip' for examples of expected output.


